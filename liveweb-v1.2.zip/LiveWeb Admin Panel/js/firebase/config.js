//Write here your firebase web config, you can access it on console.firebase.com
//Firebase Console --> Project --> Project Settings --> General --> Your Apps --> Web App





var firebaseConfig = {
  apiKey: "xxx",
  authDomain: "xxx",
  databaseURL: "xxx",
  projectId: "xxx",
  storageBucket: "xxx",
  messagingSenderId: "xxx",
  appId: "xxx",
  measurementId: "xxx"
};














// don't change
firebase.initializeApp(firebaseConfig);